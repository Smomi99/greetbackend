$(document).ready(function(){
    //------------- Send Password reset ----------//
    $('.Forgot-Pass').on('click')
    })